
USE ndap;

-- SECTION 1 — SELECT
-- Q1
SELECT DISTINCT srcStateName
FROM FarmersInsuranceData
WHERE srcStateName IS NOT NULL
ORDER BY srcStateName;

-- Q2
SELECT
  srcStateName,
  SUM(TotalFarmersCovered) AS total_farmers,
  SUM(SumInsured)          AS sum_insured
FROM FarmersInsuranceData
GROUP BY srcStateName
ORDER BY total_farmers DESC;

-- SECTION 2 — WHERE
-- Q3
SELECT *
FROM FarmersInsuranceData
WHERE srcYear = 2020;

-- Q4
SELECT *
FROM FarmersInsuranceData
WHERE srcStateName = 'HIMACHAL PRADESH'
  AND TotalPopulationRural > 1000000;

-- Q5
SELECT
  srcStateName,
  srcDistrictName,
  SUM(FarmersPremiumAmount) AS total_farmers_premium
FROM FarmersInsuranceData
WHERE srcYear = 2018
GROUP BY srcStateName, srcDistrictName
ORDER BY total_farmers_premium ASC;

-- Q6
SELECT
  srcStateName,
  SUM(TotalFarmersCovered)           AS total_farmers,
  SUM(`GrossPremiumAmountToBePaid`)  AS total_gross_premium
FROM FarmersInsuranceData
WHERE `InsuredLandArea` > 5.0
  AND srcYear = 2018
GROUP BY srcStateName;

-- SECTION 3 — GROUP BY
-- Q7
SELECT
  srcYear,
  AVG(`InsuredLandArea`) AS avg_insured_area
FROM FarmersInsuranceData
GROUP BY srcYear
ORDER BY srcYear;

-- Q8
SELECT
  srcDistrictName,
  SUM(TotalFarmersCovered) AS total_farmers
FROM FarmersInsuranceData
WHERE `Insurance units` > 0
GROUP BY srcDistrictName
ORDER BY total_farmers DESC;

-- Q9
SELECT
  srcStateName,
  SUM(FarmersPremiumAmount) AS farmers_premium,
  SUM(StatePremiumAmount)   AS state_premium,
  SUM(GOVPremiumAmount)     AS gov_premium,
  SUM(TotalFarmersCovered)  AS total_farmers
FROM FarmersInsuranceData
WHERE SumInsured > 500000
GROUP BY srcStateName;

-- SECTION 4 — ORDER BY
-- Q10
SELECT
  srcDistrictName,
  MAX(TotalPopulation) AS max_population_2020
FROM FarmersInsuranceData
WHERE srcYear = 2020
GROUP BY srcDistrictName
ORDER BY max_population_2020 DESC
LIMIT 5;

-- Q11
SELECT
  srcStateName,
  srcDistrictName,
  SumInsured,
  FarmersPremiumAmount
FROM FarmersInsuranceData
WHERE FarmersPremiumAmount > 0
ORDER BY FarmersPremiumAmount ASC, SumInsured ASC
LIMIT 10;

-- Q12
WITH ratios AS (
  SELECT
    srcStateName,
    srcYear,
    SUM(TotalFarmersCovered) AS farmers,
    SUM(TotalPopulation)     AS population
  FROM FarmersInsuranceData
  GROUP BY srcStateName, srcYear
)
SELECT
  srcStateName,
  srcYear,
  (farmers / NULLIF(population,0)) AS coverage_ratio
FROM ratios
WHERE population IS NOT NULL AND population <> 0
ORDER BY coverage_ratio DESC
LIMIT 3;

-- SECTION 5 — STRING FUNCTIONS
-- Q13
SELECT DISTINCT
  srcStateName,
  UPPER(LEFT(srcStateName,3)) AS StateShortName
FROM FarmersInsuranceData
WHERE srcStateName IS NOT NULL;

-- Q14
SELECT DISTINCT srcDistrictName
FROM FarmersInsuranceData
WHERE srcDistrictName LIKE 'B%'
ORDER BY srcDistrictName;

-- Q15
SELECT DISTINCT srcStateName, srcDistrictName
FROM FarmersInsuranceData
WHERE srcDistrictName LIKE '%pur'
ORDER BY srcStateName, srcDistrictName;

-- SECTION 6 — JOINS (self-join to satisfy join requirement)
-- Q16
SELECT
  a.srcStateName,
  a.srcDistrictName,
  a.srcYear,
  SUM(a.FarmersPremiumAmount) AS total_farmers_premium
FROM FarmersInsuranceData a
INNER JOIN FarmersInsuranceData b
  ON a.srcStateName = b.srcStateName
 AND a.srcDistrictName = b.srcDistrictName
 AND a.srcYear = b.srcYear
WHERE a.`Insurance units` > 10
GROUP BY a.srcStateName, a.srcDistrictName, a.srcYear
ORDER BY a.srcStateName, a.srcDistrictName, a.srcYear;

-- Q17 (highest FarmersPremiumAmount per district; threshold > 20 crores = 200,000,000)
WITH max_prem AS (
  SELECT
    srcStateName,
    srcDistrictName,
    MAX(FarmersPremiumAmount) AS max_farmers_premium
  FROM FarmersInsuranceData
  GROUP BY srcStateName, srcDistrictName
)
SELECT
  d.srcStateName,
  d.srcDistrictName,
  t.srcYear,
  t.TotalPopulation,
  m.max_farmers_premium
FROM max_prem m
JOIN FarmersInsuranceData t
  ON t.srcStateName = m.srcStateName
 AND t.srcDistrictName = m.srcDistrictName
JOIN FarmersInsuranceData d
  ON d.srcStateName = m.srcStateName
 AND d.srcDistrictName = m.srcDistrictName
WHERE m.max_farmers_premium > 200000000
GROUP BY d.srcStateName, d.srcDistrictName, t.srcYear, t.TotalPopulation, m.max_farmers_premium;

-- Q18 (left join population stats with farmer data; aggregate and filter > 100 crores)
WITH pop AS (
  SELECT srcStateName, srcDistrictName, AVG(TotalPopulation) AS avg_population
  FROM FarmersInsuranceData
  GROUP BY srcStateName, srcDistrictName
),
farm AS (
  SELECT srcStateName, srcDistrictName,
         SUM(TotalFarmersCovered) AS total_farmers,
         SUM(SumInsured)          AS total_suminsured,
         SUM(FarmersPremiumAmount) AS total_farmers_premium
  FROM FarmersInsuranceData
  GROUP BY srcStateName, srcDistrictName
)
SELECT
  f.srcStateName,
  f.srcDistrictName,
  f.total_farmers_premium,
  p.avg_population,
  f.total_farmers,
  f.total_suminsured
FROM farm f
LEFT JOIN pop p
  ON f.srcStateName = p.srcStateName
 AND f.srcDistrictName = p.srcDistrictName
WHERE f.total_farmers_premium > 1000000000  -- 100 Cr
ORDER BY f.total_farmers_premium DESC;

-- SECTION 7 — SUBQUERIES
-- Q19
SELECT DISTINCT srcDistrictName
FROM FarmersInsuranceData
WHERE TotalFarmersCovered > (
  SELECT AVG(TotalFarmersCovered) FROM FarmersInsuranceData
);

-- Q20
SELECT DISTINCT srcStateName
FROM FarmersInsuranceData
WHERE SumInsured > (
  SELECT SumInsured
  FROM FarmersInsuranceData
  ORDER BY FarmersPremiumAmount DESC
  LIMIT 1
);

-- Q21
SELECT DISTINCT t.srcDistrictName
FROM FarmersInsuranceData t
WHERE t.FarmersPremiumAmount > (
  SELECT AVG(FarmersPremiumAmount)
  FROM FarmersInsuranceData
  WHERE srcStateName = (
    SELECT srcStateName
    FROM FarmersInsuranceData
    ORDER BY TotalPopulation DESC
    LIMIT 1
  )
);

-- SECTION 8 — WINDOW FUNCTIONS
-- Q22
SELECT
  ROW_NUMBER() OVER (ORDER BY TotalFarmersCovered DESC) AS rn,
srcStateName,
  srcDistrictName,
  srcYear,
  TotalFarmersCovered,
  SumInsured,
  FarmersPremiumAmount,
  GrossPremiumAmountToBePaid
FROM FarmersInsuranceData;

-- Q23
SELECT
  srcStateName,
  srcDistrictName,
  SumInsured,
  RANK() OVER (PARTITION BY srcStateName ORDER BY SumInsured DESC) AS rnk
FROM FarmersInsuranceData
ORDER BY srcStateName, rnk;

-- Q24
SELECT
  srcStateName,
  srcDistrictName,
  srcYear,
  FarmersPremiumAmount,
  SUM(FarmersPremiumAmount) OVER (
    PARTITION BY srcStateName, srcDistrictName
    ORDER BY srcYear ASC
    ROWS UNBOUNDED PRECEDING
  ) AS cum_premium
FROM FarmersInsuranceData
ORDER BY srcStateName, srcDistrictName, srcYear;

-- SECTION 9 — CONSTRAINTS
-- Q25
CREATE TABLE IF NOT EXISTS states (
  StateCode INT PRIMARY KEY,
  StateName VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS districts (
  DistrictCode INT PRIMARY KEY,
  DistrictName VARCHAR(255) NOT NULL,
  StateCode INT NOT NULL
) ENGINE=InnoDB;

-- Q26
ALTER TABLE districts
  ADD CONSTRAINT fk_districts_state
  FOREIGN KEY (StateCode) REFERENCES states(StateCode);

-- SECTION 10 — UPDATE / DELETE
-- Q27
UPDATE FarmersInsuranceData
SET FarmersPremiumAmount = 500.0
WHERE srcStateName = 'HIMACHAL PRADESH' AND srcYear = 2018
LIMIT 1;

-- Q28
UPDATE FarmersInsuranceData
SET srcYear = 2021
WHERE srcStateName = 'HIMACHAL PRADESH' AND srcYear = 2018
LIMIT 1;

-- Q29
DELETE FROM FarmersInsuranceData
WHERE srcYear = 2020
  AND TotalFarmersCovered < 10000
LIMIT 1;

